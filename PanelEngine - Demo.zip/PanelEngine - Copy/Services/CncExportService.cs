using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;

namespace PanelEngine.Services
{
    public sealed class CncExportService
    {
        private const string DefaultOutputDirectory = @"C:\PanelEngine";

        public CncExportResult ExportSelectedFlattenedPanel(Document document, UIDocumentSelection selection, View sourceView)
        {
            if (document == null)
                throw new ArgumentNullException("document");

            if (selection == null)
                throw new ArgumentNullException("selection");

            if (sourceView == null)
                throw new ArgumentNullException("sourceView");

            ICollection<ElementId> selectedIds = selection.GetElementIds();
            if (selectedIds == null || selectedIds.Count == 0)
                throw new InvalidOperationException("Select one flattened PanelEngine panel instance before exporting CNC.");

            if (selectedIds.Count != 1)
                throw new InvalidOperationException("Select exactly one PanelEngine panel instance for CNC export.");

            ElementId panelId = selectedIds.First();
            var instance = document.GetElement(panelId) as FamilyInstance;
            if (instance == null)
                throw new InvalidOperationException("The selected element is not a family instance.");

            FamilySymbol symbol = instance.Symbol;
            if (!IsPanelEngineFamily(instance, symbol))
                throw new InvalidOperationException("The selected family instance is not a PanelEngine panel.");

            if (!ReadYesNoParameter(instance, symbol, "Flattened"))
                throw new InvalidOperationException("CNC export is only allowed when Flattened = TRUE. Recreate or reload this panel as flattened, then export.");

            string panelName = ReadStringParameter(instance, symbol, "PanelName");
            if (string.IsNullOrWhiteSpace(panelName))
                panelName = symbol.FamilyName;

            string safePanelName = SanitizeFileName(panelName);
            Directory.CreateDirectory(DefaultOutputDirectory);

            View exportView = null;
            string fileBaseName = safePanelName + "_FLAT";
            string expectedPath = Path.Combine(DefaultOutputDirectory, fileBaseName + ".dxf");

            try
            {
                using (var transaction = new Transaction(document, "PanelEngine Prepare CNC Export View"))
                {
                    transaction.Start();
                    exportView = CreatePrintableExportView(document, sourceView);
                    IsolatePanelInView(document, exportView, panelId);
                    transaction.Commit();
                }

                var viewIds = new List<ElementId> { exportView.Id };
                var options = new DXFExportOptions();

                bool exported = document.Export(DefaultOutputDirectory, fileBaseName, viewIds, options);
                if (!exported)
                    throw new InvalidOperationException("Revit returned false from DXF export.");

                return new CncExportResult(expectedPath);
            }
            finally
            {
                if (exportView != null && document.GetElement(exportView.Id) != null)
                {
                    using (var cleanup = new Transaction(document, "PanelEngine Cleanup CNC Export View"))
                    {
                        cleanup.Start();
                        document.Delete(exportView.Id);
                        cleanup.Commit();
                    }
                }
            }
        }

        private static View CreatePrintableExportView(Document document, View sourceView)
        {
            if (!Is2DExportView(sourceView))
                throw new InvalidOperationException("CNC export requires a printable 2D view, such as a floor plan. Open a plan view and try again.");

            View exportView = null;
            if (sourceView.CanViewBeDuplicated(ViewDuplicateOption.Duplicate))
            {
                ElementId duplicateId = sourceView.Duplicate(ViewDuplicateOption.Duplicate);
                exportView = document.GetElement(duplicateId) as View;
            }

            if (exportView == null)
                throw new InvalidOperationException("The active view cannot be duplicated for CNC export. Open a printable plan view and try again.");

            exportView.Name = "PanelEngine_CNC_Export_" + Guid.NewGuid().ToString("N").Substring(0, 8);

            if (!exportView.CanBePrinted)
                throw new InvalidOperationException("The temporary export view is not printable. Open a printable plan view and try again.");

            return exportView;
        }

        private static bool Is2DExportView(View view)
        {
            if (view == null)
                return false;

            return view.ViewType == ViewType.FloorPlan ||
                   view.ViewType == ViewType.CeilingPlan ||
                   view.ViewType == ViewType.EngineeringPlan ||
                   view.ViewType == ViewType.AreaPlan ||
                   view.ViewType == ViewType.Detail ||
                   view.ViewType == ViewType.DraftingView;
        }

        private static void IsolatePanelInView(Document document, View exportView, ElementId panelId)
        {
            var hideIds = new List<ElementId>();
            foreach (Element element in new FilteredElementCollector(document, exportView.Id).WhereElementIsNotElementType())
            {
                if (element == null || element.Id == panelId || element.Id == exportView.Id)
                    continue;

                if (element.CanBeHidden(exportView))
                    hideIds.Add(element.Id);
            }

            if (hideIds.Count > 0)
                exportView.HideElements(hideIds);
        }

        private static bool IsPanelEngineFamily(FamilyInstance instance, FamilySymbol symbol)
        {
            return HasParameter(instance, "PanelName") ||
                   HasParameter(symbol, "PanelName") ||
                   HasParameter(instance, "Flattened") ||
                   HasParameter(symbol, "Flattened");
        }

        private static bool HasParameter(Element element, string name)
        {
            return element != null && element.LookupParameter(name) != null;
        }

        private static bool ReadYesNoParameter(FamilyInstance instance, FamilySymbol symbol, string name)
        {
            Parameter parameter = FindParameter(instance, symbol, name);
            return parameter != null && parameter.StorageType == StorageType.Integer && parameter.AsInteger() == 1;
        }

        private static string ReadStringParameter(FamilyInstance instance, FamilySymbol symbol, string name)
        {
            Parameter parameter = FindParameter(instance, symbol, name);
            return parameter == null ? null : parameter.AsString();
        }

        private static Parameter FindParameter(FamilyInstance instance, FamilySymbol symbol, string name)
        {
            Parameter parameter = instance == null ? null : instance.LookupParameter(name);
            if (parameter != null)
                return parameter;

            return symbol == null ? null : symbol.LookupParameter(name);
        }

        private static string SanitizeFileName(string panelName)
        {
            string value = (panelName ?? string.Empty).Trim();
            foreach (char invalid in Path.GetInvalidFileNameChars())
                value = value.Replace(invalid, '_');

            value = value.Replace('.', '_').Trim('_', ' ');
            return value.Length == 0 ? "PanelEnginePanel" : value;
        }
    }

    public sealed class CncExportResult
    {
        public CncExportResult(string filePath)
        {
            FilePath = filePath;
        }

        public string FilePath { get; private set; }
    }

    public sealed class UIDocumentSelection
    {
        private readonly Autodesk.Revit.UI.Selection.Selection _selection;

        public UIDocumentSelection(Autodesk.Revit.UI.Selection.Selection selection)
        {
            _selection = selection;
        }

        public ICollection<ElementId> GetElementIds()
        {
            return _selection.GetElementIds();
        }
    }
}
