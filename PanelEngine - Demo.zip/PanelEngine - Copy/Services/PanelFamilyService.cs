using System;
using System.Collections.Generic;
using System.IO;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using PanelEngine.Core;
using PanelEngine.Models;

namespace PanelEngine.Services
{
    public sealed class PanelFamilyService
    {
        private const string DefaultOutputDirectory = @"C:\PanelEngine";
        private readonly GeometryNormalizer _normalizer;

        public PanelFamilyService()
        {
            _normalizer = new GeometryNormalizer();
        }

        public PanelFamilyCreationResult CreateFamily(Application application, PanelDefinition definition)
        {
            if (application == null)
                throw new ArgumentNullException("application");

            if (definition == null)
                throw new ArgumentNullException("definition");

            definition.Validate();

            string safePanelName = NormalizePanelName(definition.PanelName);
            definition.PanelName = safePanelName;
            string familyPath = Path.Combine(DefaultOutputDirectory, safePanelName + ".rfa");
            Directory.CreateDirectory(DefaultOutputDirectory);

            string templatePath = ResolveGenericModelTemplate(application);
            Document familyDocument = application.NewFamilyDocument(templatePath);

            try
            {
                BuildFamilyDocument(familyDocument, definition, safePanelName);

                var saveAsOptions = new SaveAsOptions
                {
                    OverwriteExistingFile = true
                };
                familyDocument.SaveAs(familyPath, saveAsOptions);
            }
            finally
            {
                familyDocument.Close(false);
            }

            return new PanelFamilyCreationResult(safePanelName, familyPath);
        }

        private void BuildFamilyDocument(Document familyDocument, PanelDefinition definition, string safePanelName)
        {
            IList<PanelEdge> edges = _normalizer.Normalize(definition);

            using (var transaction = new Transaction(familyDocument, "PanelEngine Build Family Geometry"))
            {
                transaction.Start();

                ConfigureFamilyParameters(familyDocument, definition, safePanelName);
                CreateReferenceEdges(familyDocument, edges, safePanelName);
                CreateOffsetReferences(familyDocument, edges, definition, safePanelName);
                CreateCorePanelSolid(familyDocument, definition, safePanelName);
                CreateFlangeSolids(familyDocument, edges, definition, safePanelName);

                transaction.Commit();
            }
        }

        private static void ConfigureFamilyParameters(Document familyDocument, PanelDefinition definition, string safePanelName)
        {
            FamilyManager manager = familyDocument.FamilyManager;

            if (manager.CurrentType == null)
                manager.NewType(safePanelName);

            FamilyParameter panelName = AddParameterIfMissing(manager, "PanelName", GroupTypeId.IdentityData, SpecTypeId.String.Text);
            FamilyParameter panelType = AddParameterIfMissing(manager, "PanelType", GroupTypeId.IdentityData, SpecTypeId.String.Text);
            FamilyParameter thickness = AddParameterIfMissing(manager, "PanelThickness", GroupTypeId.Geometry, SpecTypeId.Length);
            FamilyParameter flangeDepth = AddParameterIfMissing(manager, "FlangeDepth", GroupTypeId.Geometry, SpecTypeId.Length);
            FamilyParameter flattened = AddParameterIfMissing(manager, "Flattened", GroupTypeId.Data, SpecTypeId.Boolean.YesNo);
            FamilyParameter bendAngle = AddParameterIfMissing(manager, "BendAngle", GroupTypeId.Geometry, SpecTypeId.Angle);
            FamilyParameter effectiveAngle = AddParameterIfMissing(manager, "EffectiveAngle", GroupTypeId.Geometry, SpecTypeId.Angle);
            FamilyParameter flangeOffset = AddParameterIfMissing(manager, "FlangeOffset", GroupTypeId.Geometry, SpecTypeId.Length);
            FamilyParameter bendCompensation = AddParameterIfMissing(manager, "BendCompensation", GroupTypeId.Geometry, SpecTypeId.Length);
            FamilyParameter cornerGap = AddParameterIfMissing(manager, "CornerGap", GroupTypeId.Geometry, SpecTypeId.Length);
            FamilyParameter baseLength = AddParameterIfMissing(manager, "BaseLength", GroupTypeId.Geometry, SpecTypeId.Length);
            FamilyParameter angleLeft = AddParameterIfMissing(manager, "AngleLeft", GroupTypeId.Geometry, SpecTypeId.Angle);
            FamilyParameter angleRight = AddParameterIfMissing(manager, "AngleRight", GroupTypeId.Geometry, SpecTypeId.Angle);

            manager.Set(panelName, definition.PanelName);
            manager.Set(panelType, definition.PanelType.ToString());
            manager.Set(thickness, definition.Thickness);
            manager.Set(flangeDepth, definition.Flanges.Count > 0 ? definition.Flanges[0].Depth : 0.0);
            manager.Set(flattened, definition.Flattened ? 1 : 0);
            manager.Set(bendAngle, DegreesToRadians(definition.BendAngleDegrees));
            manager.Set(effectiveAngle, definition.EffectiveAngleRadians);
            manager.Set(flangeOffset, definition.FlangeOffset);
            manager.Set(bendCompensation, definition.BendCompensation);
            manager.Set(cornerGap, definition.CornerGap);
            manager.Set(baseLength, definition.BaseLength);
            manager.Set(angleLeft, DegreesToRadians(definition.AngleLeftDegrees));
            manager.Set(angleRight, DegreesToRadians(definition.AngleRightDegrees));
            TrySetFormula(manager, effectiveAngle, "if(Flattened, 0\u00B0, BendAngle)");
            if (string.IsNullOrEmpty(effectiveAngle.Formula))
                TrySetFormula(manager, effectiveAngle, "if(Flattened, 0, BendAngle)");
        }

        private static FamilyParameter AddParameterIfMissing(FamilyManager manager, string name, ForgeTypeId groupTypeId, ForgeTypeId specTypeId)
        {
            foreach (FamilyParameter parameter in manager.Parameters)
            {
                if (string.Equals(parameter.Definition.Name, name, StringComparison.OrdinalIgnoreCase))
                    return parameter;
            }

            return manager.AddParameter(name, groupTypeId, specTypeId, false);
        }

        private static void TrySetFormula(FamilyManager manager, FamilyParameter parameter, string formula)
        {
            try
            {
                manager.SetFormula(parameter, formula);
            }
            catch
            {
                // Formula support varies by template and localized Revit formula parsing. The generated geometry
                // still uses the same one-way EffectiveAngle value during creation if the formula is rejected.
            }
        }

        private static void CreateReferenceEdges(Document familyDocument, IEnumerable<PanelEdge> edges, string safePanelName)
        {
            SketchPlane sketchPlane = SketchPlane.Create(familyDocument, Plane.CreateByNormalAndOrigin(XYZ.BasisZ, XYZ.Zero));

            foreach (PanelEdge edge in edges)
            {
                ModelCurve curve = familyDocument.FamilyCreate.NewModelCurve(Line.CreateBound(edge.Start, edge.End), sketchPlane);
                ConstraintManager.MarkElement(curve, "ReferenceEdge:" + edge.Index, safePanelName);
            }
        }

        private void CreateOffsetReferences(Document familyDocument, IList<PanelEdge> edges, PanelDefinition definition, string safePanelName)
        {
            SketchPlane sketchPlane = SketchPlane.Create(familyDocument, Plane.CreateByNormalAndOrigin(XYZ.BasisZ, XYZ.Zero));

            foreach (FlangeDefinition flange in definition.Flanges)
            {
                PanelEdge edge = edges[flange.EdgeIndex];
                Line offset = CreateFlangePath(edge, flange);
                ModelCurve curve = familyDocument.FamilyCreate.NewModelCurve(offset, sketchPlane);
                ConstraintManager.MarkElement(curve, "OffsetReference:" + edge.Index, safePanelName);
            }
        }

        private static void CreateCorePanelSolid(Document familyDocument, PanelDefinition definition, string safePanelName)
        {
            var loop = new CurveLoop();
            for (int i = 0; i < definition.Points.Count; i++)
            {
                loop.Append(Line.CreateBound(definition.Points[i], definition.Points[(i + 1) % definition.Points.Count]));
            }

            Solid solid = GeometryCreationUtilities.CreateExtrusionGeometry(
                new List<CurveLoop> { loop },
                XYZ.BasisZ,
                definition.Thickness);

            FreeFormElement element = FreeFormElement.Create(familyDocument, solid);
            ConstraintManager.MarkElement(element, "CorePanel", safePanelName);
        }

        private void CreateFlangeSolids(Document familyDocument, IList<PanelEdge> edges, PanelDefinition definition, string safePanelName)
        {
            foreach (FlangeDefinition flange in definition.Flanges)
            {
                PanelEdge edge = edges[flange.EdgeIndex];
                Line offsetLine = CreateFlangePath(edge, flange);
                Solid solid = BuildFoldedFlangeSolid(offsetLine, edge, definition.Thickness, flange);
                FreeFormElement element = FreeFormElement.Create(familyDocument, solid);
                ConstraintManager.MarkElement(element, "Flange:" + edge.Index, safePanelName);
            }
        }

        private Line CreateFlangePath(PanelEdge edge, FlangeDefinition flange)
        {
            if (flange.CornerGap >= edge.Length)
                throw new InvalidOperationException("Corner gap is too large for edge " + edge.Index + ".");

            XYZ shorten = edge.Direction * (flange.CornerGap * 0.5);
            XYZ offset = edge.OutwardNormal * flange.Offset;
            return Line.CreateBound(edge.Start + offset + shorten, edge.End + offset - shorten);
        }

        private static Solid BuildFoldedFlangeSolid(Line offsetLine, PanelEdge edge, double thickness, FlangeDefinition flange)
        {
            double radians = flange.AngleDegrees * Math.PI / 180.0;
            XYZ hingeStart = offsetLine.GetEndPoint(0) + (XYZ.BasisZ * thickness);
            XYZ hingeEnd = offsetLine.GetEndPoint(1) + (XYZ.BasisZ * thickness);
            XYZ foldDirection = (edge.OutwardNormal * Math.Cos(radians)) - (XYZ.BasisZ * Math.Sin(radians));
            XYZ plateNormal = edge.Direction.CrossProduct(foldDirection).Normalize();
            double netDepth = flange.Depth - flange.BendCompensation;

            XYZ outerStart = hingeStart + (foldDirection * netDepth);
            XYZ outerEnd = hingeEnd + (foldDirection * netDepth);
            XYZ thicknessVector = plateNormal * thickness;

            return BuildSolid(new List<XYZ>
            {
                hingeStart,
                hingeEnd,
                outerEnd,
                outerStart,
                hingeStart + thicknessVector,
                hingeEnd + thicknessVector,
                outerEnd + thicknessVector,
                outerStart + thicknessVector
            });
        }

        private static Solid BuildSolid(IList<XYZ> v)
        {
            var builder = new TessellatedShapeBuilder();
            builder.OpenConnectedFaceSet(true);
            AddFace(builder, v[0], v[1], v[2], v[3]);
            AddFace(builder, v[4], v[7], v[6], v[5]);
            AddFace(builder, v[0], v[4], v[5], v[1]);
            AddFace(builder, v[1], v[5], v[6], v[2]);
            AddFace(builder, v[2], v[6], v[7], v[3]);
            AddFace(builder, v[3], v[7], v[4], v[0]);
            builder.CloseConnectedFaceSet();
            builder.Target = TessellatedShapeBuilderTarget.Solid;
            builder.Fallback = TessellatedShapeBuilderFallback.Abort;
            builder.Build();

            foreach (GeometryObject geometryObject in builder.GetBuildResult().GetGeometricalObjects())
            {
                var solid = geometryObject as Solid;
                if (solid != null && solid.Volume > 0.0)
                    return solid;
            }

            throw new InvalidOperationException("Could not create folded flange solid.");
        }

        private static void AddFace(TessellatedShapeBuilder builder, XYZ a, XYZ b, XYZ c, XYZ d)
        {
            builder.AddFace(new TessellatedFace(new List<XYZ> { a, b, c, d }, ElementId.InvalidElementId));
        }

        private static double DegreesToRadians(double degrees)
        {
            return degrees * Math.PI / 180.0;
        }

        private static string ResolveGenericModelTemplate(Application application)
        {
            string root = application.FamilyTemplatePath;
            var candidateNames = new[]
            {
                "Generic Model.rft",
                "Metric Generic Model.rft"
            };

            foreach (string candidateName in candidateNames)
            {
                string direct = Path.Combine(root, candidateName);
                if (File.Exists(direct))
                    return direct;
            }

            foreach (string candidateName in candidateNames)
            {
                string[] matches = Directory.GetFiles(root, candidateName, SearchOption.AllDirectories);
                if (matches.Length > 0)
                    return matches[0];
            }

            throw new FileNotFoundException("Could not find the Generic Model family template under: " + root);
        }

        private static string NormalizePanelName(string panelName)
        {
            string value = (panelName ?? string.Empty).Trim();
            if (value.EndsWith(".rfa", StringComparison.OrdinalIgnoreCase))
                value = value.Substring(0, value.Length - 4).Trim();

            value = value.Replace('.', '_');

            foreach (char invalid in Path.GetInvalidFileNameChars())
                value = value.Replace(invalid, '_');

            while (value.Contains("__"))
                value = value.Replace("__", "_");

            value = value.Trim('_', ' ');
            if (value.Length == 0)
                throw new InvalidOperationException("Panel name must contain at least one valid letter or number.");

            return value;
        }
    }

    public sealed class PanelFamilyCreationResult
    {
        public PanelFamilyCreationResult(string panelName, string familyPath)
        {
            PanelName = panelName;
            FamilyPath = familyPath;
        }

        public string PanelName { get; private set; }
        public string FamilyPath { get; private set; }
    }
}
