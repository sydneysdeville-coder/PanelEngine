using System;
using System.IO;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;

namespace PanelEngine.Services
{
    public sealed class FamilyLoadService
    {
        public Family LoadFamily(Document projectDocument, string familyPath)
        {
            if (projectDocument == null)
                throw new ArgumentNullException("projectDocument");

            if (string.IsNullOrWhiteSpace(familyPath))
                throw new ArgumentException("Family path is required.", "familyPath");

            if (projectDocument.IsFamilyDocument)
                throw new InvalidOperationException("Open a project document before loading the generated panel family.");

            var fileInfo = new FileInfo(familyPath);
            if (!fileInfo.Exists)
                throw new FileNotFoundException("The generated family file was not found.", familyPath);

            if (fileInfo.Length == 0)
                throw new InvalidOperationException("The generated family file is empty: " + familyPath);

            string expectedFamilyName = Path.GetFileNameWithoutExtension(familyPath);

            Family family;
            bool loaded;
            using (var transaction = new Transaction(projectDocument, "PanelEngine Load Family"))
            {
                transaction.Start();
                loaded = projectDocument.LoadFamily(familyPath, new PanelFamilyLoadOptions(), out family);

                if (loaded && family != null)
                    transaction.Commit();
                else
                    transaction.RollBack();
            }

            if (loaded && family != null)
                return family;

            Family existingFamily = FindFamily(projectDocument, expectedFamilyName);
            if (existingFamily != null)
                return existingFamily;

            throw new InvalidOperationException(
                "Revit could not load the generated panel family. File: " +
                familyPath +
                " (" +
                fileInfo.Length +
                " bytes). Close any open copy of this RFA, use a unique panel name, then try again.");
        }

        public ElementId PlaceAtOrigin(Document projectDocument, Family family)
        {
            if (projectDocument == null)
                throw new ArgumentNullException("projectDocument");

            if (family == null)
                throw new ArgumentNullException("family");

            ElementId symbolId = family.GetFamilySymbolIds().FirstOrDefault();
            if (symbolId == null || symbolId == ElementId.InvalidElementId)
                throw new InvalidOperationException("The generated family does not contain a placeable family symbol.");

            var symbol = projectDocument.GetElement(symbolId) as FamilySymbol;
            if (symbol == null)
                throw new InvalidOperationException("Could not retrieve the generated family symbol.");

            using (var transaction = new Transaction(projectDocument, "PanelEngine Place Family Instance"))
            {
                transaction.Start();

                if (!symbol.IsActive)
                {
                    symbol.Activate();
                    projectDocument.Regenerate();
                }

                FamilyInstance instance = projectDocument.Create.NewFamilyInstance(
                    XYZ.Zero,
                    symbol,
                    StructuralType.NonStructural);

                transaction.Commit();
                return instance.Id;
            }
        }

        private static Family FindFamily(Document document, string familyName)
        {
            return new FilteredElementCollector(document)
                .OfClass(typeof(Family))
                .Cast<Family>()
                .FirstOrDefault(family => string.Equals(family.Name, familyName, StringComparison.OrdinalIgnoreCase));
        }
    }

    internal sealed class PanelFamilyLoadOptions : IFamilyLoadOptions
    {
        public bool OnFamilyFound(bool familyInUse, out bool overwriteParameterValues)
        {
            overwriteParameterValues = true;
            return true;
        }

        public bool OnSharedFamilyFound(Family sharedFamily, bool familyInUse, out FamilySource source, out bool overwriteParameterValues)
        {
            source = FamilySource.Family;
            overwriteParameterValues = true;
            return true;
        }
    }
}
