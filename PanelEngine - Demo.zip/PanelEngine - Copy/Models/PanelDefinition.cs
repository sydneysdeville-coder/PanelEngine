using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;

namespace PanelEngine.Models
{
    public enum PanelType
    {
        Triangle,
        Rectangle
    }

    public sealed class PanelDefinition
    {
        public PanelDefinition()
        {
            Points = new List<XYZ>();
            Flanges = new List<FlangeDefinition>();
        }

        public PanelType PanelType { get; set; }
        public string PanelName { get; set; }
        public IList<XYZ> Points { get; private set; }
        public double Thickness { get; set; }
        public bool PlaceInstance { get; set; }
        public bool Flattened { get; set; }
        public double BendAngleDegrees { get; set; }
        public double FlangeOffset { get; set; }
        public double BendCompensation { get; set; }
        public double CornerGap { get; set; }
        public double BaseLength { get; set; }
        public double AngleLeftDegrees { get; set; }
        public double AngleRightDegrees { get; set; }
        public IList<FlangeDefinition> Flanges { get; private set; }

        public double EffectiveAngleDegrees
        {
            get { return Flattened ? 0.0 : BendAngleDegrees; }
        }

        public double EffectiveAngleRadians
        {
            get { return EffectiveAngleDegrees * Math.PI / 180.0; }
        }

        public static PanelDefinition CreateTriangle(double baseLength, double height, double thickness, double flangeDepth)
        {
            double angleLeft = Math.Atan2(height, 0.0) * 180.0 / Math.PI;
            double angleRight = Math.Atan2(height, baseLength) * 180.0 / Math.PI;
            return CreateTriangleFromAngles(baseLength, angleLeft, angleRight, thickness, flangeDepth);
        }

        public static PanelDefinition CreateTriangleFromAngles(double baseLength, double angleLeftDegrees, double angleRightDegrees, double thickness, double flangeDepth)
        {
            XYZ apex = CalculateApex(baseLength, angleLeftDegrees, angleRightDegrees);
            var definition = new PanelDefinition
            {
                PanelType = PanelType.Triangle,
                Thickness = thickness,
                BaseLength = baseLength,
                AngleLeftDegrees = angleLeftDegrees,
                AngleRightDegrees = angleRightDegrees
            };

            definition.Points.Add(XYZ.Zero);
            definition.Points.Add(new XYZ(baseLength, 0.0, 0.0));
            definition.Points.Add(apex);
            definition.AddFlangesForAllEdges(flangeDepth);
            return definition;
        }

        public static PanelDefinition CreateRectangle(double width, double height, double thickness, double flangeDepth)
        {
            var definition = new PanelDefinition
            {
                PanelType = PanelType.Rectangle,
                Thickness = thickness,
                BaseLength = width,
                AngleLeftDegrees = 90.0,
                AngleRightDegrees = 90.0
            };

            definition.Points.Add(XYZ.Zero);
            definition.Points.Add(new XYZ(width, 0.0, 0.0));
            definition.Points.Add(new XYZ(width, height, 0.0));
            definition.Points.Add(new XYZ(0.0, height, 0.0));
            definition.AddFlangesForAllEdges(flangeDepth);
            return definition;
        }

        public void AddFlangesForAllEdges(double depth)
        {
            Flanges.Clear();
            for (int i = 0; i < Points.Count; i++)
            {
                Flanges.Add(new FlangeDefinition
                {
                    EdgeIndex = i,
                    Depth = depth
                });
            }
        }

        public void ApplyFabricationSettingsToFlanges()
        {
            foreach (FlangeDefinition flange in Flanges)
            {
                flange.Offset = FlangeOffset;
                flange.BendCompensation = BendCompensation;
                flange.CornerGap = CornerGap;
                flange.AngleDegrees = EffectiveAngleDegrees;
            }
        }

        public void Validate()
        {
            EnsureDefaults();
            ApplyFabricationSettingsToFlanges();

            int expectedPointCount = PanelType == PanelType.Triangle ? 3 : 4;
            if (Points.Count != expectedPointCount)
                throw new InvalidOperationException("Panel point count does not match the requested panel type.");

            if (string.IsNullOrWhiteSpace(PanelName))
                throw new InvalidOperationException("Panel name is required.");

            if (Thickness <= 0.0)
                throw new InvalidOperationException("Panel thickness must be greater than zero.");

            if (BendAngleDegrees < 0.0 || BendAngleDegrees > 180.0)
                throw new InvalidOperationException("Bend angle must be between 0 and 180 degrees.");

            if (PanelType == PanelType.Triangle)
            {
                if (BaseLength <= 0.0)
                    throw new InvalidOperationException("Triangle base length must be greater than zero.");

                if (AngleLeftDegrees <= 0.0 || AngleRightDegrees <= 0.0 || AngleLeftDegrees + AngleRightDegrees >= 180.0)
                    throw new InvalidOperationException("Triangle angles must be positive and sum to less than 180 degrees.");
            }

            if (SignedArea2D() <= 1.0e-8)
                throw new InvalidOperationException("Panel points must form a non-degenerate counter-clockwise polygon.");

            foreach (var flange in Flanges)
                flange.Validate(Points.Count);
        }

        private void EnsureDefaults()
        {
            if (BendAngleDegrees == 0.0 && !Flattened)
                BendAngleDegrees = FlangeDefinition.DefaultAngleDegrees;

            if (FlangeOffset == 0.0)
                FlangeOffset = FlangeDefinition.DefaultOffsetFeet;

            if (BendCompensation == 0.0)
                BendCompensation = FlangeDefinition.DefaultBendCompensationFeet;

            if (CornerGap == 0.0)
                CornerGap = FlangeDefinition.DefaultCornerGapFeet;
        }

        private static XYZ CalculateApex(double baseLength, double angleLeftDegrees, double angleRightDegrees)
        {
            if (baseLength <= 0.0)
                throw new InvalidOperationException("Triangle base length must be greater than zero.");

            if (angleLeftDegrees <= 0.0 || angleRightDegrees <= 0.0 || angleLeftDegrees + angleRightDegrees >= 180.0)
                throw new InvalidOperationException("Triangle angles must be positive and sum to less than 180 degrees.");

            double left = angleLeftDegrees * Math.PI / 180.0;
            double right = angleRightDegrees * Math.PI / 180.0;
            XYZ leftDirection = new XYZ(Math.Cos(left), Math.Sin(left), 0.0);
            XYZ rightDirection = new XYZ(-Math.Cos(right), Math.Sin(right), 0.0);
            double denominator = Cross2D(leftDirection, rightDirection);
            if (Math.Abs(denominator) < 1.0e-9)
                throw new InvalidOperationException("Triangle angle lines do not produce a stable apex.");

            XYZ baseEnd = new XYZ(baseLength, 0.0, 0.0);
            double t = Cross2D(baseEnd, rightDirection) / denominator;
            return leftDirection * t;
        }

        private static double Cross2D(XYZ a, XYZ b)
        {
            return (a.X * b.Y) - (a.Y * b.X);
        }

        private double SignedArea2D()
        {
            double area = 0.0;
            for (int i = 0; i < Points.Count; i++)
            {
                XYZ a = Points[i];
                XYZ b = Points[(i + 1) % Points.Count];
                area += (a.X * b.Y) - (b.X * a.Y);
            }

            return area * 0.5;
        }
    }
}
