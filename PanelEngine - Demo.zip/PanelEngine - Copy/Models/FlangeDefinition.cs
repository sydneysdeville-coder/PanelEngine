using System;

namespace PanelEngine.Models
{
    public sealed class FlangeDefinition
    {
        public const double DefaultOffsetFeet = 1.0 / 32.0 / 12.0;
        public const double DefaultBendCompensationFeet = 1.0 / 32.0 / 12.0;
        public const double DefaultCornerGapFeet = 1.0 / 32.0 / 12.0;
        public const double DefaultAngleDegrees = 90.0;

        public int EdgeIndex { get; set; }
        public double Depth { get; set; }
        public double Offset { get; set; }
        public double BendCompensation { get; set; }
        public double CornerGap { get; set; }
        public double AngleDegrees { get; set; }

        public FlangeDefinition()
        {
            Offset = DefaultOffsetFeet;
            BendCompensation = DefaultBendCompensationFeet;
            CornerGap = DefaultCornerGapFeet;
            AngleDegrees = DefaultAngleDegrees;
        }

        public void Validate(int edgeCount)
        {
            if (EdgeIndex < 0 || EdgeIndex >= edgeCount)
                throw new InvalidOperationException("Flange edge index is outside the panel edge range.");

            if (Depth <= 0.0)
                throw new InvalidOperationException("Flange depth must be greater than zero.");

            if (Offset < 0.0)
                throw new InvalidOperationException("Flange offset cannot be negative.");

            if (BendCompensation < 0.0)
                throw new InvalidOperationException("Bend compensation cannot be negative.");

            if (CornerGap < 0.0)
                throw new InvalidOperationException("Corner gap cannot be negative.");

            if (Depth - BendCompensation <= 0.0)
                throw new InvalidOperationException("Flange depth must be greater than bend compensation.");

            if (AngleDegrees < 0.0 || AngleDegrees > 180.0)
                throw new InvalidOperationException("Flange angle must be between 0 and 180 degrees.");
        }
    }
}
