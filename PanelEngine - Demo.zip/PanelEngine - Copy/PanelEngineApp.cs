using System;
using System.Reflection;
using Autodesk.Revit.UI;
using PanelEngine.Commands;
using PanelEngine.UI;

namespace PanelEngine
{
    public sealed class PanelEngineApp : IExternalApplication
    {
        private const string TabName = "Panel Engine";
        private const string PanelName = "Panels";

        public Result OnStartup(UIControlledApplication application)
        {
            PanelEnginePaneContext.Initialize();
            RegisterDockablePane(application);
            CreateRibbon(application);
            return Result.Succeeded;
        }

        public Result OnShutdown(UIControlledApplication application)
        {
            PanelEnginePaneContext.Dispose();
            return Result.Succeeded;
        }

        private static void RegisterDockablePane(UIControlledApplication application)
        {
            application.RegisterDockablePane(
                PanelEnginePaneIdentifiers.DockablePaneId,
                TabName,
                new PanelEnginePaneProvider());
        }

        private static void CreateRibbon(UIControlledApplication application)
        {
            try
            {
                application.CreateRibbonTab(TabName);
            }
            catch
            {
                // Revit throws if the tab already exists during a reload.
            }

            RibbonPanel panel = GetOrCreatePanel(application);
            string assemblyPath = Assembly.GetExecutingAssembly().Location;
            var buttonData = new PushButtonData(
                "PanelEngineOpenPane",
                "Panel\nEngine",
                assemblyPath,
                typeof(CreatePanelCommand).FullName);

            PushButton button = panel.AddItem(buttonData) as PushButton;
            if (button != null)
            {
                button.ToolTip = "Open the controlled Panel Engine input pane.";
                button.LongDescription = "Create triangle and rectangle panels with derived offset references and dependent flanges.";
            }

            var exportButtonData = new PushButtonData(
                "PanelEngineExportCnc",
                "Export\nCNC",
                assemblyPath,
                typeof(ExportCncCommand).FullName);

            PushButton exportButton = panel.AddItem(exportButtonData) as PushButton;
            if (exportButton != null)
            {
                exportButton.ToolTip = "Export the selected flattened PanelEngine panel as a DXF file.";
                exportButton.LongDescription = "Creates a temporary isolated export view and uses Revit's built-in DXF export. Export is blocked unless Flattened is true.";
            }
        }

        private static RibbonPanel GetOrCreatePanel(UIControlledApplication application)
        {
            foreach (RibbonPanel panel in application.GetRibbonPanels(TabName))
            {
                if (panel.Name == PanelName)
                    return panel;
            }

            return application.CreateRibbonPanel(TabName, PanelName);
        }
    }
}
