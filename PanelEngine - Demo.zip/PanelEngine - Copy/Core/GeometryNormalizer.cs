using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using PanelEngine.Models;

namespace PanelEngine.Core
{
    public sealed class GeometryNormalizer
    {
        private const double MinimumEdgeLength = 1.0e-6;

        public IList<PanelEdge> Normalize(PanelDefinition definition)
        {
            if (definition == null)
                throw new ArgumentNullException("definition");

            definition.Validate();

            var edges = new List<PanelEdge>();
            for (int i = 0; i < definition.Points.Count; i++)
            {
                XYZ start = Flatten(definition.Points[i]);
                XYZ end = Flatten(definition.Points[(i + 1) % definition.Points.Count]);
                XYZ vector = end - start;
                double length = vector.GetLength();

                if (length < MinimumEdgeLength)
                    throw new InvalidOperationException("Panel contains an edge that is too short for stable fabrication geometry.");

                XYZ direction = vector.Normalize();
                XYZ outward = new XYZ(direction.Y, -direction.X, 0.0).Normalize();
                edges.Add(new PanelEdge(i, start, end, direction, outward, length));
            }

            return edges;
        }

        public Line CreateOffsetLine(PanelEdge edge, double offset)
        {
            XYZ delta = edge.OutwardNormal * offset;
            return Line.CreateBound(edge.Start + delta, edge.End + delta);
        }

        private static XYZ Flatten(XYZ point)
        {
            return new XYZ(point.X, point.Y, 0.0);
        }
    }

    public sealed class PanelEdge
    {
        public PanelEdge(int index, XYZ start, XYZ end, XYZ direction, XYZ outwardNormal, double length)
        {
            Index = index;
            Start = start;
            End = end;
            Direction = direction;
            OutwardNormal = outwardNormal;
            Length = length;
        }

        public int Index { get; private set; }
        public XYZ Start { get; private set; }
        public XYZ End { get; private set; }
        public XYZ Direction { get; private set; }
        public XYZ OutwardNormal { get; private set; }
        public double Length { get; private set; }
    }
}
