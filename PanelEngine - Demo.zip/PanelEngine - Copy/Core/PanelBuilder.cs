using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using PanelEngine.Models;

namespace PanelEngine.Core
{
    public sealed class PanelBuilder
    {
        public void CreateReferenceEdges(Document familyDocument, IEnumerable<PanelEdge> edges, string panelName)
        {
            SketchPlane sketchPlane = SketchPlane.Create(familyDocument, Plane.CreateByNormalAndOrigin(XYZ.BasisZ, XYZ.Zero));

            foreach (PanelEdge edge in edges)
            {
                ModelCurve curve = familyDocument.FamilyCreate.NewModelCurve(Line.CreateBound(edge.Start, edge.End), sketchPlane);
                ConstraintManager.MarkElement(curve, "ReferenceEdge:" + edge.Index, panelName);
            }
        }

        public void CreateOffsetReferences(Document familyDocument, GeometryNormalizer normalizer, IList<PanelEdge> edges, PanelDefinition definition, string panelName)
        {
            SketchPlane sketchPlane = SketchPlane.Create(familyDocument, Plane.CreateByNormalAndOrigin(XYZ.BasisZ, XYZ.Zero));

            foreach (FlangeDefinition flange in definition.Flanges)
            {
                PanelEdge edge = edges[flange.EdgeIndex];
                Line offset = CreateFlangePath(edge, flange);
                ModelCurve curve = familyDocument.FamilyCreate.NewModelCurve(offset, sketchPlane);
                ConstraintManager.MarkElement(curve, "OffsetReference:" + edge.Index, panelName);
            }
        }

        public void CreateCorePanelSolid(Document familyDocument, PanelDefinition definition, string panelName)
        {
            var loop = new CurveLoop();
            for (int i = 0; i < definition.Points.Count; i++)
            {
                loop.Append(Line.CreateBound(definition.Points[i], definition.Points[(i + 1) % definition.Points.Count]));
            }

            Solid solid = GeometryCreationUtilities.CreateExtrusionGeometry(
                new List<CurveLoop> { loop },
                XYZ.BasisZ,
                definition.Thickness);

            FreeFormElement element = FreeFormElement.Create(familyDocument, solid);
            ConstraintManager.MarkElement(element, "CorePanel", panelName);
        }

        public void CreateFlangeSolids(Document familyDocument, GeometryNormalizer normalizer, IList<PanelEdge> edges, PanelDefinition definition, string panelName)
        {
            foreach (FlangeDefinition flange in definition.Flanges)
            {
                PanelEdge edge = edges[flange.EdgeIndex];
                Line offsetLine = CreateFlangePath(edge, flange);
                Solid solid = BuildFoldedFlangeSolid(offsetLine, edge, definition.Thickness, flange);
                FreeFormElement element = FreeFormElement.Create(familyDocument, solid);
                ConstraintManager.MarkElement(element, "Flange:" + edge.Index, panelName);
            }
        }

        private static Line CreateFlangePath(PanelEdge edge, FlangeDefinition flange)
        {
            if (flange.CornerGap >= edge.Length)
                throw new InvalidOperationException("Corner gap is too large for edge " + edge.Index + ".");

            XYZ shorten = edge.Direction * (flange.CornerGap * 0.5);
            XYZ offset = edge.OutwardNormal * flange.Offset;
            return Line.CreateBound(edge.Start + offset + shorten, edge.End + offset - shorten);
        }

        private static Solid BuildFoldedFlangeSolid(Line offsetLine, PanelEdge edge, double thickness, FlangeDefinition flange)
        {
            double radians = flange.AngleDegrees * Math.PI / 180.0;
            XYZ hingeStart = offsetLine.GetEndPoint(0) + (XYZ.BasisZ * thickness);
            XYZ hingeEnd = offsetLine.GetEndPoint(1) + (XYZ.BasisZ * thickness);
            XYZ foldDirection = (edge.OutwardNormal * Math.Cos(radians)) - (XYZ.BasisZ * Math.Sin(radians));
            XYZ plateNormal = edge.Direction.CrossProduct(foldDirection).Normalize();
            double netDepth = flange.Depth - flange.BendCompensation;

            XYZ outerStart = hingeStart + (foldDirection * netDepth);
            XYZ outerEnd = hingeEnd + (foldDirection * netDepth);
            XYZ thicknessVector = plateNormal * thickness;

            return BuildSolid(new List<XYZ>
            {
                hingeStart,
                hingeEnd,
                outerEnd,
                outerStart,
                hingeStart + thicknessVector,
                hingeEnd + thicknessVector,
                outerEnd + thicknessVector,
                outerStart + thicknessVector
            });
        }

        private static Solid BuildSolid(IList<XYZ> v)
        {
            var builder = new TessellatedShapeBuilder();
            builder.OpenConnectedFaceSet(true);
            AddFace(builder, v[0], v[1], v[2], v[3]);
            AddFace(builder, v[4], v[7], v[6], v[5]);
            AddFace(builder, v[0], v[4], v[5], v[1]);
            AddFace(builder, v[1], v[5], v[6], v[2]);
            AddFace(builder, v[2], v[6], v[7], v[3]);
            AddFace(builder, v[3], v[7], v[4], v[0]);
            builder.CloseConnectedFaceSet();
            builder.Target = TessellatedShapeBuilderTarget.Solid;
            builder.Fallback = TessellatedShapeBuilderFallback.Abort;
            builder.Build();

            foreach (GeometryObject geometryObject in builder.GetBuildResult().GetGeometricalObjects())
            {
                var solid = geometryObject as Solid;
                if (solid != null && solid.Volume > 0.0)
                    return solid;
            }

            throw new InvalidOperationException("Could not create folded flange solid.");
        }

        private static void AddFace(TessellatedShapeBuilder builder, XYZ a, XYZ b, XYZ c, XYZ d)
        {
            builder.AddFace(new TessellatedFace(new List<XYZ> { a, b, c, d }, ElementId.InvalidElementId));
        }
    }
}
