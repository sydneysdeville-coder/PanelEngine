using System.Collections.Generic;
using Autodesk.Revit.DB;

namespace PanelEngine.Core
{
    public sealed class ConstraintManager
    {
        public void AssertNoGeneratedConstraints(Document document, IEnumerable<ElementId> generatedElementIds)
        {
            // PanelEngine intentionally creates no Revit dimensions, locks, joins, or family constraints.
            // The generated ids are accepted here so future rebuild logic has one choke point for audits.
            if (document == null || generatedElementIds == null)
                return;
        }

        public static void MarkElement(Element element, string role, string panelId)
        {
            if (element == null)
                return;

            Parameter comments = element.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
            if (comments != null && !comments.IsReadOnly)
                comments.Set("PanelEngine|" + panelId + "|" + role);
        }
    }
}
