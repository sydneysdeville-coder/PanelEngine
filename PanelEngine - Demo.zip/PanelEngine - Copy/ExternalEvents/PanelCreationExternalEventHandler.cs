using System;
using Autodesk.Revit.UI;
using PanelEngine.Models;
using PanelEngine.Services;

namespace PanelEngine.UI
{
    internal sealed class PanelCreationExternalEventHandler : IExternalEventHandler
    {
        private readonly object _sync = new object();
        private readonly Action<string> _reportStatus;
        private PanelDefinition _pendingDefinition;

        public PanelCreationExternalEventHandler(Action<string> reportStatus)
        {
            _reportStatus = reportStatus;
        }

        public string GetName()
        {
            return "Panel Engine Create Panel";
        }

        public void SetRequest(PanelDefinition definition)
        {
            lock (_sync)
            {
                _pendingDefinition = definition;
            }
        }

        public void Execute(UIApplication app)
        {
            PanelDefinition definition;
            lock (_sync)
            {
                definition = _pendingDefinition;
                _pendingDefinition = null;
            }

            if (definition == null)
                return;

            try
            {
                if (app.ActiveUIDocument == null)
                    throw new InvalidOperationException("Open a Revit document before creating a panel.");

                var familyService = new PanelFamilyService();
                PanelFamilyCreationResult familyResult = familyService.CreateFamily(app.Application, definition);

                var loadService = new FamilyLoadService();
                Autodesk.Revit.DB.Family family = loadService.LoadFamily(app.ActiveUIDocument.Document, familyResult.FamilyPath);

                string status = "Saved and loaded family: " + familyResult.FamilyPath;
                if (definition.PlaceInstance)
                {
                    Autodesk.Revit.DB.ElementId instanceId = loadService.PlaceAtOrigin(app.ActiveUIDocument.Document, family);
                    status += "\nPlaced instance id: " + instanceId.Value;
                }

                _reportStatus(status);
            }
            catch (Exception ex)
            {
                _reportStatus("Panel creation failed: " + ex.Message);
            }
        }
    }
}
