using System;
using Autodesk.Revit.UI;
using PanelEngine.Services;

namespace PanelEngine.UI
{
    internal sealed class CncExportExternalEventHandler : IExternalEventHandler
    {
        private readonly Action<string> _reportStatus;

        public CncExportExternalEventHandler(Action<string> reportStatus)
        {
            _reportStatus = reportStatus;
        }

        public string GetName()
        {
            return "Panel Engine Export CNC DXF";
        }

        public void Execute(UIApplication app)
        {
            try
            {
                if (app.ActiveUIDocument == null)
                    throw new InvalidOperationException("Open a Revit project and select one flattened PanelEngine panel before exporting CNC.");

                var service = new CncExportService();
                CncExportResult result = service.ExportSelectedFlattenedPanel(
                    app.ActiveUIDocument.Document,
                    new UIDocumentSelection(app.ActiveUIDocument.Selection),
                    app.ActiveUIDocument.ActiveView);

                _reportStatus("CNC DXF exported: " + result.FilePath);
            }
            catch (Exception ex)
            {
                _reportStatus("CNC export failed: " + ex.Message);
            }
        }
    }
}
