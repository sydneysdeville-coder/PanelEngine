using System;
using Autodesk.Revit.UI;
using PanelEngine.Models;

namespace PanelEngine.UI
{
    internal static class PanelEnginePaneContext
    {
        private static PanelCreationExternalEventHandler _creationHandler;
        private static ExternalEvent _creationExternalEvent;
        private static CncExportExternalEventHandler _cncExportHandler;
        private static ExternalEvent _cncExportExternalEvent;

        public static event Action<string> StatusChanged;

        public static void Initialize()
        {
            if (_creationHandler != null)
                return;

            _creationHandler = new PanelCreationExternalEventHandler(ReportStatus);
            _creationExternalEvent = ExternalEvent.Create(_creationHandler);
            _cncExportHandler = new CncExportExternalEventHandler(ReportStatus);
            _cncExportExternalEvent = ExternalEvent.Create(_cncExportHandler);
        }

        public static void Submit(PanelDefinition definition)
        {
            if (_creationHandler == null || _creationExternalEvent == null)
                throw new InvalidOperationException("Panel Engine pane was not initialized.");

            _creationHandler.SetRequest(definition);
            _creationExternalEvent.Raise();
        }

        public static void ExportCnc()
        {
            if (_cncExportExternalEvent == null)
                throw new InvalidOperationException("Panel Engine pane was not initialized.");

            _cncExportExternalEvent.Raise();
        }

        public static void Dispose()
        {
            if (_creationExternalEvent != null)
            {
                _creationExternalEvent.Dispose();
                _creationExternalEvent = null;
            }

            if (_cncExportExternalEvent != null)
            {
                _cncExportExternalEvent.Dispose();
                _cncExportExternalEvent = null;
            }

            _creationHandler = null;
            _cncExportHandler = null;
        }

        private static void ReportStatus(string message)
        {
            Action<string> statusChanged = StatusChanged;
            if (statusChanged != null)
                statusChanged(message);
        }
    }
}
