using System;
using Autodesk.Revit.UI;

namespace PanelEngine.UI
{
    internal static class PanelEnginePaneIdentifiers
    {
        public static readonly DockablePaneId DockablePaneId =
            new DockablePaneId(new Guid("4F98798E-E541-490F-A2FD-901C8264037C"));
    }
}
