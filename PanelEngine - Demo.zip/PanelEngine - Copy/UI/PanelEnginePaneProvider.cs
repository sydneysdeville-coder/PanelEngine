using Autodesk.Revit.UI;

namespace PanelEngine.UI
{
    internal sealed class PanelEnginePaneProvider : IDockablePaneProvider
    {
        public void SetupDockablePane(DockablePaneProviderData data)
        {
            data.FrameworkElement = new PanelEnginePane();
            data.InitialState = new DockablePaneState
            {
                DockPosition = DockPosition.Right
            };
        }
    }
}
