using System;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using PanelEngine.Models;

namespace PanelEngine.UI
{
    internal sealed class PanelEnginePane : System.Windows.Controls.UserControl
    {
        private readonly System.Windows.Controls.ComboBox _panelType;
        private readonly System.Windows.Controls.TextBox _panelNameValue;
        private readonly System.Windows.Controls.TextBlock _primaryLabel;
        private readonly System.Windows.Controls.TextBox _primaryValue;
        private readonly System.Windows.Controls.TextBlock _secondaryLabel;
        private readonly System.Windows.Controls.TextBox _secondaryValue;
        private readonly System.Windows.Controls.StackPanel _angleRightStack;
        private readonly System.Windows.Controls.TextBox _angleRightValue;
        private readonly System.Windows.Controls.TextBox _thicknessValue;
        private readonly System.Windows.Controls.TextBox _flangeDepthValue;
        private readonly System.Windows.Controls.TextBox _bendAngleValue;
        private readonly System.Windows.Controls.TextBox _flangeOffsetValue;
        private readonly System.Windows.Controls.TextBox _bendCompensationValue;
        private readonly System.Windows.Controls.TextBox _cornerGapValue;
        private readonly System.Windows.Controls.CheckBox _flattenedValue;
        private readonly System.Windows.Controls.CheckBox _placeInstanceValue;
        private readonly System.Windows.Controls.TextBlock _status;

        public PanelEnginePane()
        {
            Background = new SolidColorBrush(Color.FromRgb(24, 24, 24));

            var root = new System.Windows.Controls.Grid
            {
                Margin = new Thickness(18)
            };
            for (int i = 0; i < 17; i++)
                root.RowDefinitions.Add(new System.Windows.Controls.RowDefinition { Height = i == 16 ? new GridLength(1, GridUnitType.Star) : GridLength.Auto });

            AddHeader(root);

            _panelNameValue = CreateTextBox("TS_RECT_48x36_F1_5");
            AddLabeledControl(root, "Panel name", _panelNameValue, 1);

            _panelType = CreateComboBox();
            _panelType.Items.Add("Rectangle");
            _panelType.Items.Add("Triangle");
            _panelType.SelectedIndex = 0;
            _panelType.SelectionChanged += delegate { UpdatePanelTypeLabels(); };
            AddLabeledControl(root, "Panel type", _panelType, 2);

            _primaryLabel = CreateLabel("Width (in)");
            _primaryValue = CreateTextBox("48");
            AddLabeledControl(root, _primaryLabel, _primaryValue, 3);

            _secondaryLabel = CreateLabel("Height (in)");
            _secondaryValue = CreateTextBox("36");
            AddLabeledControl(root, _secondaryLabel, _secondaryValue, 4);

            _angleRightValue = CreateTextBox("45");
            _angleRightStack = CreateLabeledStack(CreateLabel("Angle right (deg)"), _angleRightValue);
            _angleRightStack.Visibility = Visibility.Collapsed;
            System.Windows.Controls.Grid.SetRow(_angleRightStack, 5);
            root.Children.Add(_angleRightStack);

            _thicknessValue = CreateTextBox("0.125");
            AddLabeledControl(root, "Thickness (in)", _thicknessValue, 6);

            _flangeDepthValue = CreateTextBox("1.5");
            AddLabeledControl(root, "Flange depth (in)", _flangeDepthValue, 7);

            _bendAngleValue = CreateTextBox("90");
            AddLabeledControl(root, "Bend angle (deg)", _bendAngleValue, 8);

            _flangeOffsetValue = CreateTextBox("0.03125");
            AddLabeledControl(root, "Flange offset (in)", _flangeOffsetValue, 9);

            _bendCompensationValue = CreateTextBox("0.03125");
            AddLabeledControl(root, "Bend compensation (in)", _bendCompensationValue, 10);

            _cornerGapValue = CreateTextBox("0.03125");
            AddLabeledControl(root, "Corner gap (in)", _cornerGapValue, 11);

            _flattenedValue = new System.Windows.Controls.CheckBox
            {
                Content = "Flattened",
                IsChecked = false,
                Foreground = new SolidColorBrush(Color.FromRgb(220, 220, 220)),
                Margin = new Thickness(0, 4, 0, 8)
            };
            System.Windows.Controls.Grid.SetRow(_flattenedValue, 12);
            root.Children.Add(_flattenedValue);

            _placeInstanceValue = new System.Windows.Controls.CheckBox
            {
                Content = "Place instance at origin",
                IsChecked = true,
                Foreground = new SolidColorBrush(Color.FromRgb(220, 220, 220)),
                Margin = new Thickness(0, 4, 0, 8)
            };
            System.Windows.Controls.Grid.SetRow(_placeInstanceValue, 13);
            root.Children.Add(_placeInstanceValue);

            var createButton = new System.Windows.Controls.Button
            {
                Content = "Create Panel",
                Height = 38,
                Margin = new Thickness(0, 14, 0, 0),
                Background = new SolidColorBrush(Color.FromRgb(222, 177, 70)),
                Foreground = Brushes.Black,
                BorderBrush = Brushes.Transparent,
                FontWeight = FontWeights.SemiBold
            };
            createButton.Click += OnCreatePanel;
            System.Windows.Controls.Grid.SetRow(createButton, 14);
            root.Children.Add(createButton);

            var exportButton = new System.Windows.Controls.Button
            {
                Content = "Export CNC",
                Height = 34,
                Margin = new Thickness(0, 8, 0, 0),
                Background = new SolidColorBrush(Color.FromRgb(72, 72, 72)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(105, 105, 105)),
                FontWeight = FontWeights.SemiBold
            };
            exportButton.Click += OnExportCnc;
            System.Windows.Controls.Grid.SetRow(exportButton, 15);
            root.Children.Add(exportButton);

            _status = new System.Windows.Controls.TextBlock
            {
                Text = "Ready. Creates a named .rfa, loads it into the project, and optionally places an instance.",
                Foreground = new SolidColorBrush(Color.FromRgb(190, 190, 190)),
                Margin = new Thickness(0, 16, 0, 0),
                TextWrapping = TextWrapping.Wrap
            };
            System.Windows.Controls.Grid.SetRow(_status, 16);
            root.Children.Add(_status);

            Content = new System.Windows.Controls.ScrollViewer
            {
                VerticalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Auto,
                Content = root
            };

            PanelEnginePaneContext.StatusChanged += OnStatusChanged;
            Unloaded += delegate { PanelEnginePaneContext.StatusChanged -= OnStatusChanged; };
        }

        private void AddHeader(System.Windows.Controls.Grid root)
        {
            var stack = new System.Windows.Controls.StackPanel
            {
                Margin = new Thickness(0, 0, 0, 14)
            };

            stack.Children.Add(new System.Windows.Controls.TextBlock
            {
                Text = "Panel Engine",
                Foreground = Brushes.White,
                FontSize = 22,
                FontWeight = FontWeights.SemiBold
            });

            stack.Children.Add(new System.Windows.Controls.TextBlock
            {
                Text = "Controlled fabrication panels",
                Foreground = new SolidColorBrush(Color.FromRgb(170, 170, 170)),
                Margin = new Thickness(0, 4, 0, 0)
            });

            System.Windows.Controls.Grid.SetRow(stack, 0);
            root.Children.Add(stack);
        }

        private void AddLabeledControl(System.Windows.Controls.Grid root, string label, System.Windows.FrameworkElement control, int row)
        {
            AddLabeledControl(root, CreateLabel(label), control, row);
        }

        private static void AddLabeledControl(System.Windows.Controls.Grid root, System.Windows.Controls.TextBlock label, System.Windows.FrameworkElement control, int row)
        {
            var stack = CreateLabeledStack(label, control);
            System.Windows.Controls.Grid.SetRow(stack, row);
            root.Children.Add(stack);
        }

        private static System.Windows.Controls.StackPanel CreateLabeledStack(System.Windows.Controls.TextBlock label, System.Windows.FrameworkElement control)
        {
            var stack = new System.Windows.Controls.StackPanel
            {
                Margin = new Thickness(0, 0, 0, 10)
            };
            stack.Children.Add(label);
            stack.Children.Add(control);
            return stack;
        }

        private static System.Windows.Controls.TextBlock CreateLabel(string text)
        {
            return new System.Windows.Controls.TextBlock
            {
                Text = text,
                Foreground = new SolidColorBrush(Color.FromRgb(210, 210, 210)),
                Margin = new Thickness(0, 0, 0, 4)
            };
        }

        private static System.Windows.Controls.TextBox CreateTextBox(string value)
        {
            return new System.Windows.Controls.TextBox
            {
                Text = value,
                Height = 30,
                Padding = new Thickness(8, 4, 8, 4),
                Background = new SolidColorBrush(Color.FromRgb(38, 38, 38)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(88, 88, 88))
            };
        }

        private static System.Windows.Controls.ComboBox CreateComboBox()
        {
            return new System.Windows.Controls.ComboBox
            {
                Height = 30,
                Padding = new Thickness(6, 2, 6, 2),
                Background = new SolidColorBrush(Color.FromRgb(38, 38, 38)),
                Foreground = Brushes.Black
            };
        }

        private void UpdatePanelTypeLabels()
        {
            bool triangle = IsTriangleSelected();
            _primaryLabel.Text = triangle ? "Base length (in)" : "Width (in)";
            _secondaryLabel.Text = triangle ? "Angle left (deg)" : "Height (in)";
            _secondaryValue.Text = triangle ? "45" : "36";
            _angleRightStack.Visibility = triangle ? Visibility.Visible : Visibility.Collapsed;
        }

        private void OnCreatePanel(object sender, RoutedEventArgs e)
        {
            try
            {
                double primary = ReadPositiveInches(_primaryValue, _primaryLabel.Text);
                double secondary = IsTriangleSelected()
                    ? ReadPositiveDegrees(_secondaryValue, "Angle left")
                    : ReadPositiveInches(_secondaryValue, "Height");
                double thickness = ReadPositiveInches(_thicknessValue, "Thickness");
                double flangeDepth = ReadPositiveInches(_flangeDepthValue, "Flange depth");
                double bendAngle = ReadNonNegativeDegrees(_bendAngleValue, "Bend angle");
                double flangeOffset = ReadNonNegativeInches(_flangeOffsetValue, "Flange offset");
                double bendCompensation = ReadNonNegativeInches(_bendCompensationValue, "Bend compensation");
                double cornerGap = ReadNonNegativeInches(_cornerGapValue, "Corner gap");
                string panelName = ReadPanelName();

                PanelDefinition definition = IsTriangleSelected()
                    ? PanelDefinition.CreateTriangleFromAngles(
                        InchesToFeet(primary),
                        secondary,
                        ReadPositiveDegrees(_angleRightValue, "Angle right"),
                        InchesToFeet(thickness),
                        InchesToFeet(flangeDepth))
                    : PanelDefinition.CreateRectangle(InchesToFeet(primary), InchesToFeet(secondary), InchesToFeet(thickness), InchesToFeet(flangeDepth));
                definition.PanelName = panelName;
                definition.PlaceInstance = _placeInstanceValue.IsChecked == true;
                definition.Flattened = _flattenedValue.IsChecked == true;
                definition.BendAngleDegrees = bendAngle;
                definition.FlangeOffset = InchesToFeet(flangeOffset);
                definition.BendCompensation = InchesToFeet(bendCompensation);
                definition.CornerGap = InchesToFeet(cornerGap);
                definition.ApplyFabricationSettingsToFlanges();

                _status.Text = "Creating family " + definition.PanelName + "...";
                PanelEnginePaneContext.Submit(definition);
            }
            catch (Exception ex)
            {
                _status.Text = ex.Message;
            }
        }

        private void OnExportCnc(object sender, RoutedEventArgs e)
        {
            try
            {
                _status.Text = "Exporting selected flattened panel to DXF...";
                PanelEnginePaneContext.ExportCnc();
            }
            catch (Exception ex)
            {
                _status.Text = ex.Message;
            }
        }

        private bool IsTriangleSelected()
        {
            return string.Equals(_panelType.SelectedItem as string, "Triangle", StringComparison.OrdinalIgnoreCase);
        }

        private static double ReadPositiveInches(System.Windows.Controls.TextBox box, string label)
        {
            double value;
            if (!double.TryParse(box.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value <= 0.0)
                throw new InvalidOperationException(label + " must be a positive number.");

            return value;
        }

        private static double ReadNonNegativeInches(System.Windows.Controls.TextBox box, string label)
        {
            double value;
            if (!double.TryParse(box.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value < 0.0)
                throw new InvalidOperationException(label + " must be zero or a positive number.");

            return value;
        }

        private static double ReadPositiveDegrees(System.Windows.Controls.TextBox box, string label)
        {
            double value;
            if (!double.TryParse(box.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value <= 0.0)
                throw new InvalidOperationException(label + " must be a positive number of degrees.");

            return value;
        }

        private static double ReadNonNegativeDegrees(System.Windows.Controls.TextBox box, string label)
        {
            double value;
            if (!double.TryParse(box.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || value < 0.0 || value > 180.0)
                throw new InvalidOperationException(label + " must be between 0 and 180 degrees.");

            return value;
        }

        private string ReadPanelName()
        {
            string value = (_panelNameValue.Text ?? string.Empty).Trim();
            if (value.Length == 0)
                throw new InvalidOperationException("Panel name is required.");

            if (value.EndsWith(".rfa", StringComparison.OrdinalIgnoreCase))
                value = value.Substring(0, value.Length - 4).Trim();

            value = value.Replace('.', '_');
            return value;
        }

        private static double InchesToFeet(double inches)
        {
            return inches / 12.0;
        }

        private void OnStatusChanged(string message)
        {
            Dispatcher.BeginInvoke(new Action(delegate
            {
                _status.Text = message;
            }));
        }
    }
}
