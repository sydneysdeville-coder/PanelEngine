using System;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PanelEngine.Services;

namespace PanelEngine.Commands
{
    [Transaction(TransactionMode.Manual)]
    public sealed class ExportCncCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                UIDocument uiDocument = commandData.Application.ActiveUIDocument;
                if (uiDocument == null)
                    throw new InvalidOperationException("Open a Revit project and select one flattened PanelEngine panel before exporting CNC.");

                var service = new CncExportService();
                CncExportResult result = service.ExportSelectedFlattenedPanel(
                    uiDocument.Document,
                    new UIDocumentSelection(uiDocument.Selection),
                    uiDocument.ActiveView);

                TaskDialog.Show("Panel Engine", "CNC DXF exported:\n" + result.FilePath);
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("Panel Engine", "CNC export failed:\n" + ex.Message);
                return Result.Failed;
            }
        }
    }
}
