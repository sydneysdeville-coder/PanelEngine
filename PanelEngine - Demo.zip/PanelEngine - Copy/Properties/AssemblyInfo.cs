using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("PanelEngine")]
[assembly: AssemblyDescription("Controlled Revit panel and flange generation add-in.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("PanelEngine")]
[assembly: AssemblyProduct("PanelEngine")]
[assembly: AssemblyCopyright("Copyright 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("7E95BC70-09D5-4E66-A0DF-7332905AF65C")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
