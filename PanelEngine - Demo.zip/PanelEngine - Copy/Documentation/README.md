# PanelEngine

PanelEngine is a standalone Revit add-in for controlled triangle panels, rectangle panels, and dependent folded flanges.

The design deliberately avoids bidirectional constraints:

1. Core panel polygon is the only geometric authority.
2. Reference edges are rebuilt from the core polygon.
3. Offset references are derived once from reference edges.
4. Flanges are generated from offset references and never dimension back to the panel.

Generated output uses real Revit elements:

- `DirectShape` solid for the core panel.
- `ModelCurve` reference edges.
- `ModelCurve` offset reference lines.
- `DirectShape` solids for folded flanges.

No Revit dimensions, locks, family constraints, angle constraints, joins, or flange-to-core drivers are created.

## Project Layout

- `Commands/CreateTrianglePanelCommand.cs`
- `Commands/CreateRectanglePanelCommand.cs`
- `Commands/PanelEngineCommand.cs`
- `Core/PanelBuilder.cs`
- `Core/ConstraintManager.cs`
- `Core/GeometryNormalizer.cs`
- `Models/PanelDefinition.cs`
- `Models/FlangeDefinition.cs`
- `Services/PanelCreationService.cs`
- `Services/FlangeGenerationService.cs`

## Build

1. Open `PanelEngine.sln` in Visual Studio.
2. Confirm the project targets `.NET 8.0-windows` for Revit 2025.
3. Set platform to `x64`.
4. Confirm `RevitAPI.dll` and `RevitAPIUI.dll` references point to your Revit install folder.
5. Build `Release|x64`.

The project uses this default reference path:

```xml
C:\Program Files\Autodesk\Revit 2025\
```

You can override it from MSBuild:

```powershell
dotnet build PanelEngine.sln -c Release -p:Platform=x64 -p:RevitInstallDir="C:\Program Files\Autodesk\Revit 2025\"
```

## Revit 2025 Runtime

This project is SDK-style and targets `.NET 8.0-windows` for Revit 2025. It references `RevitAPI.dll` and `RevitAPIUI.dll` from the Revit 2025 install folder and does not copy those assemblies into the add-in output.

## Add-in Manifest

Copy `PanelEngine.addin` to the per-user Revit add-in folder and update each `<Assembly>` value to the built DLL path.

Typical legacy per-user path:

```text
%APPDATA%\Autodesk\Revit\Addins\2025\PanelEngine.addin
```

Example assembly path:

```xml
<Assembly>C:\Users\sydne\Documents\Codex\2026-05-05\files-mentioned-by-the-user-typesafe\PanelEngine\bin\x64\Release\PanelEngine.dll</Assembly>
```

After Revit loads a valid command manifest, the commands appear under:

```text
Add-Ins -> External Tools
```

## Stability Rules

- Do not add Revit lock constraints between flanges and panel edges.
- Do not dimension flanges to triangle side lengths or angles.
- Do not offset an already-offset line.
- Rebuild from the original `PanelDefinition` whenever dimensions change.
- Treat flanges as disposable dependent geometry during rebuilds.

## Extending for Perforations

Add a `PerforationDefinition` model with host scope, pattern type, radius or slot size, spacing, and edge clearances. Generate perforations as subtractive loops in the core panel extrusion or as separate fabrication metadata first. Keep perforation placement derived from the core polygon coordinate frame, never from flange geometry.

## Supporting Bending Logic

Add a `BendDefinition` model with bend line, inside radius, K-factor, material thickness, and developed length rules. The bend line should be derived from the offset reference. Bending calculations should produce flange geometry and flat pattern data, but the bend should not rewrite triangle or rectangle points.

## Long-Term Constraint Stability

Use rebuilds instead of persistent geometric constraints. Store compact source definitions, delete dependent geometry by panel id, and recreate reference edges, offset lines, flanges, perforations, and bends from the driver. Add validation gates for minimum edge length, nonzero area, flange overlap, and material-specific minimum bend radius.

## Larger TypeSafe-Like Evolution

PanelEngine can grow into a controlled fabrication system by adding:

- Versioned `PanelDefinition` persistence.
- A rebuild command for selected PanelEngine output.
- Material libraries and bend tables.
- Clash and manufacturability checks.
- Change previews before committing geometry.
- Export adapters for CNC, DXF, schedules, and QA reports.
